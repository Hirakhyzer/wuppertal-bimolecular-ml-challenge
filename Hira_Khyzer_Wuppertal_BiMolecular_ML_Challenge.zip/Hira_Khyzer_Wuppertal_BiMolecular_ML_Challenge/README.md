# Bi-molecular Machine Learning Challenge - Wuppertal

This repository contains a reproducible Kernel Ridge Regression (KRR) solution for the University of Wuppertal bi-molecular machine-learning challenge.

## Method in brief

For each A-B geometry pair, the supplied `Coord_supermol.xyz` record is treated as a 30-atom supermolecule. A flattened upper-triangular Coulomb matrix is constructed:

- diagonal: `0.5 * Z_i^2.4`
- off-diagonal: `Z_i * Z_j / ||R_i - R_j||`

The descriptor has 465 features and retains cross-molecule distance terms, which are necessary for representing pairwise interaction geometry. Features are standardized using training data only. An RBF Kernel Ridge Regression model predicts the coupling energy.

## Reproducibility

The original `BiMolData.tgz` challenge dataset is not included. Obtain it only from the official challenge source, then extract it:

```bash
tar -xzf BiMolData.tgz
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python challenge_solution.py --data-dir /path/to/extracted/data --output-dir results --run-validation-sweep
```

Expected files in `--data-dir`:

```text
Coord_A.xyz
Coord_B.xyz
Coord_supermol.xyz
CouplingEnergies.csv
```

The code uses `Coord_supermol.xyz` and `CouplingEnergies.csv`; the individual coordinate files are retained to document the source data structure.

## Evaluation protocol used in the submitted report

A fixed random split with seed `104729` creates 30,000 candidate training pairs, 2,000 validation pairs, and 8,000 held-out test pairs. Hyperparameters are screened on the validation subset. The submitted learning curve fits each model on the indicated prefix of the candidate-training pool and reports MAE on the same untouched 8,000-pair test set.

## Submission materials

- `Hira_Khyzer_BiMolecular_ML_One_Page_Report.pdf` is the one-page technical report.
- `06_Hira_Khyzer_BiMolecular_ML_Challenge.pdf` starts with that report and then appends the complete source-code listing for portal upload.
- `Hira_Khyzer_Wuppertal_BiMolecular_ML_Challenge.zip` is the archive intended for the link in the cover letter.

## Transparency about LLM support

LLM assistance was used for code structuring, implementation review, visualization layout, and documentation. The challenge requires full prompt history when LLMs are used; the archive includes `PROMPT_HISTORY.md`.
