# LLM Prompt History - Bi-molecular Machine Learning Challenge

This file records the user prompts that materially guided LLM-assisted work on the challenge. The LLM was used as an implementation and documentation assistant. The applicant is responsible for reviewing, understanding, and validating all submitted code, experimental choices, and results.

## Prompt 1

> I have completed other documentations help me with following Mandatory programming-challenge PDF: One-page technical report; Double-log learning curve; Method, model parameters, validation approach, and MAE results; Full source-code listing after the report.

## Prompt 2

> @GitHub you have access to my github I DONT know what you mean you can go check even add something into it. if you need me to upload real dataset or somethng I CAN DO that just tell me which and from where dataset needed. otherwise complete everything by yourself you have my permission

## Prompt 3

> @GitHub following is the file and content make it exactly what is needed with proper detailed descriptons, complex images, tables, complex graphs , complex flowdiagrams oka?

The user then pasted the official challenge specification and uploaded `BiMolData.tgz`, which contained `Coord_A.xyz`, `Coord_B.xyz`, `CouplingEnergies.csv`, and `Coord_supermol.xyz`.

## LLM-assisted actions

1. Inspected the supplied files and verified that `CouplingEnergies.csv` contains 40,000 indexed A-B pairs.
2. Implemented a supermolecule Coulomb-matrix descriptor and RBF Kernel Ridge Regression experiment.
3. Used a fixed, documented train/validation/test protocol and computed all reported MAE values from the uploaded data.
4. Generated the learning-curve plot, one-page report, code listing, README, and archive structure.
5. Did not use external molecular data, fabricated data, or invented numerical results.
