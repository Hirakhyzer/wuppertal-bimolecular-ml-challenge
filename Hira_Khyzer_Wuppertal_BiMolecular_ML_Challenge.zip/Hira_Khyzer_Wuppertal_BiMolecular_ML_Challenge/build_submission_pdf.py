"""Build the portal PDF: one technical report page followed by source-code listings."""
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageBreak, Paragraph, Preformatted, Spacer,
    Table, TableStyle,
)
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results" / "learning_curve_results.csv"
REPORT = ROOT / "submission" / "Hira_Khyzer_BiMolecular_ML_One_Page_Report.pdf"
PORTAL = ROOT / "submission" / "06_Hira_Khyzer_BiMolecular_ML_Challenge.pdf"


def load_results():
    with RESULTS.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def make_learning_curve_png(rows, output: Path):
    x = [int(row["n_train"]) for row in rows]
    y = [float(row["mae_test"]) for row in rows]
    plt.figure(figsize=(6.25, 3.85))
    plt.loglog(x, y, marker="o")
    plt.xlabel("Number of training bi-molecular pairs")
    plt.ylabel("Held-out test MAE")
    plt.grid(True, which="both", alpha=0.35)
    plt.tight_layout()
    plt.savefig(output, dpi=240, bbox_inches="tight")
    plt.close()


def report_page(c: canvas.Canvas, rows, curve_path: Path):
    width, height = A4
    margin = 1.20 * cm
    # Header
    c.setTitle("Bi-molecular Machine Learning Challenge - Hira Khyzer")
    c.setFont("Helvetica-Bold", 13.2)
    c.drawCentredString(width / 2, height - margin, "Bi-molecular Excitonic-Coupling Regression")
    c.setFont("Helvetica", 8.2)
    c.drawCentredString(width / 2, height - margin - 0.40 * cm,
                        "University of Wuppertal Challenge | Kernel Ridge Regression with a Supermolecule Coulomb Matrix")
    c.setStrokeColor(colors.black)
    c.setLineWidth(0.5)
    c.line(margin, height - margin - 0.63 * cm, width - margin, height - margin - 0.63 * cm)

    # Objective / contribution
    y = height - margin - 1.05 * cm
    c.setFont("Helvetica-Bold", 8.8)
    c.drawString(margin, y, "Objective and modelling decision")
    y -= 0.36 * cm
    objective = (
        "Predict the scalar coupling energy for ordered geometry pairs (A, B). "
        "Each supplied A-B record is represented as one 30-atom supermolecule, so the descriptor preserves "
        "cross-molecule distances rather than treating the two molecules independently."
    )
    draw_wrapped(c, objective, margin, y, width - 2 * margin, 7.35, 8.8)

    # Chart + method column
    chart_x = margin
    chart_y = 14.15 * cm
    chart_w = 10.60 * cm
    chart_h = 7.00 * cm
    c.drawImage(str(curve_path), chart_x, chart_y, chart_w, chart_h, preserveAspectRatio=True, anchor='sw')
    c.setFont("Helvetica", 6.65)
    c.drawString(chart_x, chart_y - 0.28 * cm,
                 "Figure 1. Double-log learning curve; MAE is evaluated on the same untouched 8,000-pair test set.")

    col_x = margin + 11.00 * cm
    col_w = width - margin - col_x
    c.setFont("Helvetica-Bold", 8.8)
    c.drawString(col_x, 17.65 * cm, "Experimental protocol")
    protocol = [
        ("Data", "40,000 coupling records; 200 x 200 ordered pairs."),
        ("Representation", "Upper triangle of a 30 x 30 Coulomb matrix (465 features)."),
        ("Split", "Seed 104729: 30,000 candidate-train / 2,000 validation / 8,000 test."),
        ("Scaling", "StandardScaler fit only on the active training subset."),
        ("Model", "RBF Kernel Ridge Regression, alpha = 1e-6."),
        ("Kernel width", "gamma = 0.10 / median(||x_i-x_j||^2), recomputed per training size."),
        ("Metric", "Mean absolute error (MAE) in the coupling-energy units supplied in the CSV."),
    ]
    yy = 17.26 * cm
    for label, text in protocol:
        c.setFont("Helvetica-Bold", 6.8)
        c.drawString(col_x, yy, label + ":")
        c.setFont("Helvetica", 6.8)
        yy = draw_wrapped(c, text, col_x + 2.25 * cm, yy, col_w - 2.25 * cm, 6.8, 7.75) - 0.07 * cm

    # Result table
    c.setFont("Helvetica-Bold", 8.8)
    c.drawString(col_x, 12.65 * cm, "Measured learning-curve points")
    table_rows = [["Train pairs", "Test MAE"]]
    for row in rows:
        table_rows.append([f"{int(row['n_train']):,}", f"{float(row['mae_test']):.3f}"])
    table = Table(table_rows, colWidths=[2.12 * cm, 1.75 * cm], rowHeights=0.42 * cm)
    table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.35, colors.black),
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 6.8),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
    ]))
    table.wrapOn(c, col_w, 5 * cm)
    table.drawOn(c, col_x, 8.85 * cm)

    # Workflow flow diagram
    workflow_y = 6.32 * cm
    c.setFont("Helvetica-Bold", 8.8)
    c.drawString(margin, workflow_y + 0.57 * cm, "Reproducible workflow")
    labels = [
        "XYZ + energy\nCSV",
        "30-atom\nsupermolecule",
        "Coulomb matrix\n(465 features)",
        "Train-only\nstandardization",
        "RBF KRR\nfit + predict",
        "MAE + log-log\nlearning curve",
    ]
    x0 = margin
    box_w = 2.72 * cm
    box_h = 1.05 * cm
    gap = 0.38 * cm
    by = workflow_y - 0.54 * cm
    for i, label in enumerate(labels):
        bx = x0 + i * (box_w + gap)
        c.roundRect(bx, by, box_w, box_h, 0.10 * cm, stroke=1, fill=0)
        c.setFont("Helvetica", 6.45)
        lines = label.split("\n")
        for j, line in enumerate(lines):
            text_width = stringWidth(line, "Helvetica", 6.45)
            c.drawString(bx + (box_w - text_width) / 2, by + box_h - 0.38 * cm - j * 0.30 * cm, line)
        if i < len(labels) - 1:
            ax = bx + box_w
            ay = by + box_h / 2
            c.line(ax + 0.05 * cm, ay, ax + gap - 0.08 * cm, ay)
            c.line(ax + gap - 0.08 * cm, ay, ax + gap - 0.20 * cm, ay + 0.09 * cm)
            c.line(ax + gap - 0.08 * cm, ay, ax + gap - 0.20 * cm, ay - 0.09 * cm)

    # Interpretation / limitations
    text_y = 4.65 * cm
    c.setFont("Helvetica-Bold", 8.8)
    c.drawString(margin, text_y, "Interpretation and limitations")
    interpretation = (
        "The error falls from 15.504 at 100 pairs to 0.135 at 8,000 pairs, showing that this descriptor-model combination "
        "benefits strongly from additional pair samples. The reported split evaluates random held-out pairs; because geometry "
        "identities can recur across pairs, a stricter future study should also hold out entire A and/or B geometry identities. "
        "The source code, exact seed, parameters, plot data, and LLM prompt history are included in the accompanying archive."
    )
    draw_wrapped(c, interpretation, margin, text_y - 0.38 * cm, width - 2 * margin, 7.15, 8.55)

    c.setStrokeColor(colors.black)
    c.line(margin, 1.55 * cm, width - margin, 1.55 * cm)
    c.setFont("Helvetica-Oblique", 6.35)
    c.drawString(margin, 1.24 * cm, "Submission package: one-page report + full code listing; original BiMolData.tgz is not redistributed.")
    c.drawRightString(width - margin, 1.24 * cm, "Applicant: Hira Khyzer")
    c.showPage()


def draw_wrapped(c, text, x, y, max_width, font_size, leading):
    c.setFont("Helvetica", font_size)
    words = text.split()
    line = ""
    current_y = y
    for word in words:
        candidate = f"{line} {word}".strip()
        if stringWidth(candidate, "Helvetica", font_size) <= max_width:
            line = candidate
        else:
            c.drawString(x, current_y, line)
            current_y -= leading
            line = word
    if line:
        c.drawString(x, current_y, line)
        current_y -= leading
    return current_y


class FirstReportCanvas(canvas.Canvas):
    """Canvas that writes the report page before Platypus code-listing pages."""
    pass


def build_one_page_report(rows, curve):
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(REPORT), pagesize=A4)
    report_page(c, rows, curve)
    c.save()


def header_footer(c, doc):
    c.saveState()
    c.setFont("Helvetica", 7)
    c.drawString(1.25 * cm, 0.75 * cm, "Bi-molecular ML Challenge - complete source-code listing")
    c.drawRightString(A4[0] - 1.25 * cm, 0.75 * cm, f"Page {doc.page + 1}")
    c.restoreState()


def build_portal_pdf(rows, curve):
    # Build the report first, then code pages as a separate PDF, finally merge them.
    code_pdf = ROOT / "submission" / "_code_listing.pdf"
    styles = getSampleStyleSheet()
    title = ParagraphStyle("CodeTitle", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=12, leading=14, alignment=TA_CENTER, spaceAfter=8)
    file_heading = ParagraphStyle("FileHeading", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=9, leading=11, spaceBefore=9, spaceAfter=4)
    source_style = ParagraphStyle("Source", fontName="Courier", fontSize=5.8, leading=6.9, leftIndent=0, rightIndent=0)
    frame = Frame(1.15 * cm, 1.1 * cm, A4[0] - 2.3 * cm, A4[1] - 2.1 * cm, id="code")
    doc = BaseDocTemplate(str(code_pdf), pagesize=A4, leftMargin=1.15 * cm, rightMargin=1.15 * cm, topMargin=1.1 * cm, bottomMargin=1.1 * cm)
    from reportlab.platypus import PageTemplate
    doc.addPageTemplates([PageTemplate(id="Code", frames=[frame], onPage=header_footer)])
    story = [Paragraph("Complete Source-Code Listing", title), Paragraph(
        "The following files are the complete source code and build instructions included in the reproducibility archive. "
        "The challenge dataset is intentionally not included.", styles["BodyText"]), Spacer(1, 6)]
    files = ["challenge_solution.py", "build_submission_pdf.py", "README.md", "requirements.txt"]
    for filename in files:
        content = (ROOT / filename).read_text(encoding="utf-8")
        story.append(Paragraph(filename, file_heading))
        numbered = "\n".join(f"{i:>4}  {line}" for i, line in enumerate(content.splitlines(), 1))
        story.append(Preformatted(numbered, source_style, maxLineLength=140))
        story.append(Spacer(1, 8))
    doc.build(story)

    from pypdf import PdfReader, PdfWriter
    writer = PdfWriter()
    for page in PdfReader(str(REPORT)).pages:
        writer.add_page(page)
    for page in PdfReader(str(code_pdf)).pages:
        writer.add_page(page)
    with PORTAL.open("wb") as output:
        writer.write(output)
    code_pdf.unlink(missing_ok=True)


def main():
    rows = load_results()
    curve = ROOT / "results" / "learning_curve.png"
    make_learning_curve_png(rows, curve)
    build_one_page_report(rows, curve)
    build_portal_pdf(rows, curve)
    print(REPORT)
    print(PORTAL)


if __name__ == "__main__":
    main()
