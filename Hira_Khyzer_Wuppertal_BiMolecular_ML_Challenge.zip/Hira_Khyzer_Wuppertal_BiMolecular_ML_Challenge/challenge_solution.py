"""Bi-molecular excitonic-coupling regression with Coulomb matrices and Kernel Ridge Regression.

This script is a reproducible solution for the University of Wuppertal challenge.
It uses the supplied supermolecule geometries so that the descriptor includes
both intramolecular structure and the relative arrangement of molecules A and B.
No challenge data are redistributed by this repository.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.kernel_ridge import KernelRidge
from sklearn.metrics import mean_absolute_error
from sklearn.metrics.pairwise import pairwise_distances
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

ATOMIC_NUMBERS = {"H": 1.0, "C": 6.0, "N": 7.0, "O": 8.0}
SEED = 104729


@dataclass(frozen=True)
class Split:
    train_pool: np.ndarray
    validation: np.ndarray
    test: np.ndarray


@dataclass
class LearningCurvePoint:
    n_train: int
    mae_test: float
    gamma: float
    alpha: float
    median_squared_distance: float


def read_concatenated_xyz(path: Path) -> tuple[np.ndarray, list[str]]:
    """Read a concatenated XYZ file and return coordinates and one atom ordering.

    The supplied data use a consistent 30-atom ordering for all 40,000
    supermolecule geometries. The explicit check prevents silently mixing
    incompatible atom orderings.
    """
    geometries: list[np.ndarray] = []
    reference_symbols: list[str] | None = None
    with path.open("r", encoding="utf-8") as handle:
        while True:
            atom_count_line = handle.readline()
            if not atom_count_line:
                break
            atom_count = int(atom_count_line.strip())
            _comment = handle.readline()
            symbols: list[str] = []
            coordinates: list[list[float]] = []
            for _ in range(atom_count):
                fields = handle.readline().split()
                if len(fields) != 4:
                    raise ValueError(f"Malformed XYZ record in {path}.")
                element, x, y, z = fields
                if element not in ATOMIC_NUMBERS:
                    raise ValueError(f"Unsupported element {element!r}.")
                symbols.append(element)
                coordinates.append([float(x), float(y), float(z)])
            if reference_symbols is None:
                reference_symbols = symbols
            elif symbols != reference_symbols:
                raise ValueError("Atom ordering differs between geometries.")
            geometries.append(np.asarray(coordinates, dtype=np.float64))
    if not geometries or reference_symbols is None:
        raise ValueError(f"No geometries were parsed from {path}.")
    return np.stack(geometries), reference_symbols


def coulomb_matrix_upper_triangle(
    coordinates: np.ndarray, atom_symbols: list[str]
) -> np.ndarray:
    """Create flattened upper-triangular Coulomb-matrix descriptors.

    C_ii = 0.5 Z_i^2.4 and C_ij = Z_i Z_j / ||R_i-R_j|| for i != j.
    The input is a full supermolecule, so cross-molecule terms are retained.
    """
    atomic_numbers = np.asarray([ATOMIC_NUMBERS[s] for s in atom_symbols])
    deltas = coordinates[:, :, None, :] - coordinates[:, None, :, :]
    distances = np.sqrt(np.maximum(np.sum(deltas * deltas, axis=-1), 1e-24))
    matrix = (
        atomic_numbers[None, :, None] * atomic_numbers[None, None, :]
    ) / np.where(distances == 0.0, np.inf, distances)
    diagonal = np.arange(len(atomic_numbers))
    matrix[:, diagonal, diagonal] = 0.5 * atomic_numbers**2.4
    upper = np.triu_indices(len(atomic_numbers))
    return matrix[:, upper[0], upper[1]].astype(np.float32, copy=False)


def make_split(n_samples: int, seed: int = SEED) -> Split:
    """Create disjoint train-pool, validation, and test index sets."""
    all_indices = np.arange(n_samples)
    remaining, test = train_test_split(
        all_indices, test_size=0.20, random_state=seed, shuffle=True
    )
    train_pool, validation = train_test_split(
        remaining, test_size=2000, random_state=seed, shuffle=True
    )
    return Split(train_pool=np.asarray(train_pool), validation=np.asarray(validation), test=np.asarray(test))


def median_heuristic_gamma(scaled_train: np.ndarray, multiplier: float = 0.10) -> tuple[float, float]:
    """Return gamma = multiplier / median(||x_i-x_j||^2) on at most 300 points."""
    probe = scaled_train[: min(300, len(scaled_train))]
    squared_distances = pairwise_distances(probe, squared=True)
    median_distance = float(np.median(squared_distances[np.triu_indices_from(squared_distances, k=1)]))
    return multiplier / median_distance, median_distance


def fit_and_score(
    features: np.ndarray,
    targets: np.ndarray,
    train_indices: np.ndarray,
    evaluation_indices: np.ndarray,
    alpha: float,
    gamma_multiplier: float,
) -> tuple[float, float, float]:
    """Fit standardized RBF-KRR and return MAE, gamma, and median distance."""
    scaler = StandardScaler().fit(features[train_indices])
    x_train = scaler.transform(features[train_indices])
    x_evaluation = scaler.transform(features[evaluation_indices])
    gamma, median_distance = median_heuristic_gamma(x_train, gamma_multiplier)
    model = KernelRidge(alpha=alpha, kernel="rbf", gamma=gamma)
    model.fit(x_train, targets[train_indices])
    prediction = model.predict(x_evaluation)
    mae = float(mean_absolute_error(targets[evaluation_indices], prediction))
    return mae, gamma, median_distance


def build_learning_curve(
    features: np.ndarray,
    targets: np.ndarray,
    split: Split,
    sizes: Iterable[int],
    alpha: float = 1e-6,
    gamma_multiplier: float = 0.10,
) -> list[LearningCurvePoint]:
    """Evaluate a fixed-split learning curve on the held-out test pairs."""
    points: list[LearningCurvePoint] = []
    for n_train in sizes:
        if n_train > len(split.train_pool):
            raise ValueError(f"Requested {n_train} train pairs, but only {len(split.train_pool)} are available.")
        mae, gamma, median_distance = fit_and_score(
            features, targets, split.train_pool[:n_train], split.test, alpha, gamma_multiplier
        )
        points.append(
            LearningCurvePoint(
                n_train=int(n_train), mae_test=mae, gamma=gamma,
                alpha=alpha, median_squared_distance=median_distance,
            )
        )
    return points


def select_parameters(
    features: np.ndarray,
    targets: np.ndarray,
    split: Split,
    n_train: int = 8000,
) -> dict[str, float]:
    """Small validation sweep; this is run before the final learning curve."""
    candidates = [
        (1e-6, 0.08), (1e-6, 0.10), (1e-5, 0.08),
        (1e-5, 0.10), (1e-4, 0.10),
    ]
    records = []
    for alpha, multiplier in candidates:
        mae, gamma, _ = fit_and_score(
            features, targets, split.train_pool[:n_train], split.validation, alpha, multiplier
        )
        records.append({"alpha": alpha, "gamma_multiplier": multiplier, "gamma": gamma, "mae_validation": mae})
    return min(records, key=lambda item: item["mae_validation"])


def plot_learning_curve(points: list[LearningCurvePoint], output: Path) -> None:
    """Create the required double-logarithmic learning-curve figure."""
    x = [point.n_train for point in points]
    y = [point.mae_test for point in points]
    plt.figure(figsize=(6.7, 4.1))
    plt.loglog(x, y, marker="o")
    plt.xlabel("Number of training bi-molecular pairs")
    plt.ylabel("Held-out test MAE")
    plt.grid(True, which="both", alpha=0.35)
    plt.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=240, bbox_inches="tight")
    plt.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True, help="Folder containing Coord_supermol.xyz and CouplingEnergies.csv")
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    parser.add_argument("--sizes", default="100,250,500,1000,2000,4000,8000")
    parser.add_argument("--run-validation-sweep", action="store_true")
    args = parser.parse_args()

    coordinates, symbols = read_concatenated_xyz(args.data_dir / "Coord_supermol.xyz")
    outputs = pd.read_csv(args.data_dir / "CouplingEnergies.csv")
    targets = outputs["coupling_energy"].to_numpy(dtype=np.float64)
    if len(coordinates) != len(targets):
        raise ValueError("Number of geometries and energy records differs.")
    features = coulomb_matrix_upper_triangle(coordinates, symbols)
    split = make_split(len(targets))
    sizes = [int(value) for value in args.sizes.split(",")]

    args.output_dir.mkdir(parents=True, exist_ok=True)
    parameter_selection = None
    if args.run_validation_sweep:
        parameter_selection = select_parameters(features, targets, split)
        (args.output_dir / "validation_sweep.json").write_text(json.dumps(parameter_selection, indent=2), encoding="utf-8")

    points = build_learning_curve(features, targets, split, sizes)
    plot_learning_curve(points, args.output_dir / "learning_curve.png")
    result = {
        "seed": SEED,
        "n_total": int(len(targets)),
        "n_train_pool": int(len(split.train_pool)),
        "n_validation": int(len(split.validation)),
        "n_test": int(len(split.test)),
        "representation": "upper triangular 30x30 supermolecule Coulomb matrix (465 features)",
        "results": [asdict(point) for point in points],
        "parameter_selection": parameter_selection,
    }
    (args.output_dir / "learning_curve_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    pd.DataFrame(result["results"]).to_csv(args.output_dir / "learning_curve_results.csv", index=False)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
